BRIDGE BANG DIEM TRONG TRAN - MAY GAME / LAN
Yeu cau Windows 10/11 va Node.js >=22.13 tren may chay Free Fire.
1. Tren web /live-scoreboard, bam Ket noi game tren may nay hoac Tai bridge cho may game.
2. Giai nen TOAN BO Overlay-Studio-Game-Bridge.zip tren may chay Free Fire.
3. Mo START.cmd va giu cua so nay chay. Web tu nhan ket noi, khong can bam ket noi lan nua.
Cau hinh serverUrl va khoa rieng da duoc web them vao ZIP. Khong can chep ca du an.
Player.log duoc doc theo tai khoan Windows hien tai; khong can cai game vao o D hay bat bang L.
May game can truy cap duoc dia chi may chu web trong file cau hinh (cung LAN).
Neu tai tren may chu bang localhost, hay mo web bang IP LAN truoc khi tai de chuyen sang may game.
Tai goi moi se thay khoa cu. Khong chia se ZIP da co cau hinh; khong dua khoa vao Git.
Nguon va che do live/replay duoc dieu khien tren web. OCR bang L la nguon du phong.
