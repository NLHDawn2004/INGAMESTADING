@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Can cai Node.js 22.13 tro len tren may chay Free Fire.
 pause
 exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)"
if errorlevel 1 (
 echo Node.js qua cu. Can Node.js 22.13 tro len.
 pause
 exit /b 1
)
if not exist ".live-scoreboard.local.json" (
 echo Hay tai bo bridge co san cau hinh tu nut Ket noi game tren web.
 echo Giai nen TOAN BO ZIP truoc khi chay START.cmd.
 pause
 exit /b 1
)
echo Giu cua so nay chay tren may co Free Fire. Web se tu nhan ket noi.
node bridge.mjs --config ".live-scoreboard.local.json"
pause
