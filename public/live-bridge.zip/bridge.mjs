var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};

// node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path: path2, errorMaps, issueData } = params;
  const fullPath = [...path2, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path2, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path2;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options2) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options2) });
  }
  ip(options2) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options2) });
  }
  cidr(options2) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options2) });
  }
  datetime(options2) {
    if (typeof options2 === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options2
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options2?.precision === "undefined" ? null : options2?.precision,
      offset: options2?.offset ?? false,
      local: options2?.local ?? false,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options2) {
    if (typeof options2 === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options2
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options2?.precision === "undefined" ? null : options2?.precision,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options2) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options2?.position,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema2 = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema2));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema2 = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema2;
      } else {
        newShape[key] = fieldSchema2.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema2 = this.shape[key];
        let newField = fieldSchema2;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options2 = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options2.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options2) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options2, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options2) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options: options2,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg2) => {
        addIssueToContext(ctx, arg2);
        if (arg2.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg2) => ZodString.create({ ...arg2, coerce: true })),
  number: ((arg2) => ZodNumber.create({ ...arg2, coerce: true })),
  boolean: ((arg2) => ZodBoolean.create({
    ...arg2,
    coerce: true
  })),
  bigint: ((arg2) => ZodBigInt.create({ ...arg2, coerce: true })),
  date: ((arg2) => ZodDate.create({ ...arg2, coerce: true }))
};
var NEVER = INVALID;

// lib/live-timing.ts
var LIVE_SOURCE_BUDGET_MS = 3e3;

// lib/overlay-layout.ts
var overlayRegionSchema = external_exports.object({ x: external_exports.number().min(0).max(1880), y: external_exports.number().min(0).max(1040), width: external_exports.number().min(40).max(1920), height: external_exports.number().min(40).max(1080) }).superRefine((r, c) => {
  if (r.x + r.width > 1920 || r.y + r.height > 1080) c.addIssue({ code: "custom", message: "V\xF9ng n\u1ED9i dung ph\u1EA3i n\u1EB1m trong khung 1920 \xD7 1080." });
});
var scheduleDesignSchema = external_exports.object({ background: external_exports.string().max(300).refine((v) => !v || /^\/api\/media\/[a-f0-9-]+$/.test(v) || /^\/score-templates\/[a-z0-9-]+\.(png|jpg|webp)$/.test(v)), maps: overlayRegionSchema, table: overlayRegionSchema, showTitle: external_exports.boolean().default(true), showHeader: external_exports.boolean().default(true) });

// lib/team-assets.ts
var teamLogoSchema = external_exports.string().max(300).refine((v) => !v || /^\/local-team-logos\/[a-f0-9]{64}$/.test(v) || /^\/(maps\/[A-Za-z]+\.webp|api\/media\/[a-f0-9-]+)$/.test(v) || /^\/logos\/(?:[\p{L}\p{N}_ -]+\/)*[\p{L}\p{N}_ .-]+\.(png|jpe?g|webp|gif)$/iu.test(v) && !v.includes(".."), "D\xF9ng \u0111\u01B0\u1EDDng d\u1EABn /logos/ten-team.png");

// lib/team-identity.ts
function teamNameKey(value) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/\s+/g, "");
}

// lib/typography.ts
var fontFamilies = ["GFF Latin", "GFF VN", "Arial", "Arial Black", "Calibri", "Cambria", "Candara", "Times New Roman", "Georgia", "Verdana", "Tahoma", "Trebuchet MS", "Bodoni MT Condensed", "Bernard MT Condensed", "Book Antiqua", "Bookman Old Style", "Broadway", "Cascadia Code", "Cascadia Mono"];
var textRoles = ["title", "subtitle", "tableHeader", "teamName", "numbers", "rank", "booyah", "winnerName", "winnerStats", "winnerStatsLabel", "pageNumber", "mapName", "status", "matchNumber", "matchLabel", "unlimited", "unlimitedLabel", "mystery"];
var textStyleSchema = external_exports.object({ family: external_exports.enum(fontFamilies), weight: external_exports.number().int().min(100).max(950), size: external_exports.number().min(8).max(288).optional() });
var typographySchema = external_exports.record(external_exports.enum(textRoles), textStyleSchema);
var region = (key, label, size, weight = 800) => ({ key, label, size, weight });
var typographyRegions = {
  map: [region("mapName", "T\xEAn map", 20), region("teamName", "T\xEAn \u0111\u1ED9i th\u1EAFng", 17), region("status", "Tr\u1EA1ng th\xE1i tr\u1EADn", 16), region("matchLabel", "Ch\u1EEF TR\u1EACN / RANDOM", 27), region("matchNumber", "S\u1ED1 tr\u1EADn", 14), region("booyah", "BOOYAH!", 38), region("unlimited", "Ch\u1EEF S\u1ED0 TR\u1EACN tr\xEAn th\u1EBB v\xF4 h\u1EA1n", 38), region("unlimitedLabel", "Ch\u1EEF KH\xD4NG GI\u1EDAI H\u1EA0N", 14), region("mystery", "D\u1EA5u h\u1ECFi map b\xED m\u1EADt", 155)],
  match: [region("title", "Ti\xEAu \u0111\u1EC1 b\u1EA3ng", 72), region("subtitle", "T\xEAn tr\u1EADn", 30), region("tableHeader", "Ti\xEAu \u0111\u1EC1 c\xE1c c\u1ED9t", 17), region("teamName", "T\xEAn \u0111\u1ED9i trong b\u1EA3ng", 25), region("numbers", "\u0110i\u1EC3m h\u1EA1ng / ELIMS / \u0111i\u1EC3m t\u1ED5ng", 30), region("rank", "Th\u1EE9 h\u1EA1ng \u0111\u1ED9i", 25), region("booyah", "BOOYAH!", 60), region("winnerName", "T\xEAn \u0111\u1ED9i BOOYAH", 32), region("winnerStatsLabel", "Nh\xE3n th\xF4ng s\u1ED1 BOOYAH", 25), region("winnerStats", "S\u1ED1 li\u1EC7u BOOYAH", 32), region("pageNumber", "S\u1ED1 trang", 18)],
  total: [region("title", "Ti\xEAu \u0111\u1EC1 b\u1EA3ng", 84), region("subtitle", "D\xF2ng ph\u1EE5", 33), region("tableHeader", "Ti\xEAu \u0111\u1EC1 c\xE1c c\u1ED9t", 12, 700), region("teamName", "T\xEAn \u0111\u1ED9i trong b\u1EA3ng", 27), region("numbers", "BOOYAH / ELIMS / \u0111i\u1EC3m t\u1ED5ng", 30), region("rank", "Th\u1EE9 h\u1EA1ng \u0111\u1ED9i", 23), region("pageNumber", "S\u1ED1 trang", 18)]
};

// lib/score-template.ts
var color = external_exports.string().regex(/^#[a-fA-F0-9]{6}$/);
var templateGroupSchema = external_exports.object({ x: external_exports.number().min(0).max(1920), y: external_exports.number().min(0).max(1080), width: external_exports.number().min(40).max(1920), rowHeight: external_exports.number().min(16).max(1080), rowGap: external_exports.number().min(16).max(1080), rows: external_exports.number().int().min(1).max(20), statsX: external_exports.number().min(0).max(1920), statsWidth: external_exports.number().min(16).max(1920), statPositions: external_exports.array(external_exports.number().min(0).max(1920)).min(1).max(4).optional() }).superRefine((g, c) => {
  if (g.x + g.width > 1921 || g.y + (g.rows - 1) * g.rowGap + g.rowHeight > 1081 || g.statsX + g.statsWidth > g.width + 1) c.addIssue({ code: "custom", message: "V\xF9ng d\u1EEF li\u1EC7u ph\u1EA3i n\u1EB1m trong \u1EA3nh m\u1EABu 1920 \xD7 1080." });
});
var scoreTemplateSchema = external_exports.object({ image: external_exports.string().max(300).regex(/^\/(api\/media\/[a-f0-9-]+|score-templates\/[a-z0-9-]+\.(png|jpg|webp))$/), label: external_exports.string().max(100), dataRegion: overlayRegionSchema.optional(), inferredRows: external_exports.boolean().optional(), subtitleRegion: external_exports.object({ x: external_exports.number().min(0).max(1920), y: external_exports.number().min(0).max(1080), width: external_exports.number().min(16).max(1920), height: external_exports.number().min(16).max(1080) }).optional(), groups: external_exports.array(templateGroupSchema).min(1).max(4), stats: external_exports.array(external_exports.enum(["booyah", "placementPoints", "kills", "total"])).min(1).max(4).refine((stats) => new Set(stats).size === stats.length, "M\u1ED7i c\u1ED9t c\u1EA7n m\u1ED9t ch\u1EC9 s\u1ED1 kh\xE1c nhau."), nameColor: color, numberColor: color, rankColor: color, highlightColor: color, coverPrintedRanks: external_exports.boolean(), logoX: external_exports.number().min(0).max(1920), logoSize: external_exports.number().min(8).max(300), nameX: external_exports.number().min(0).max(1920), rankX: external_exports.number().min(0).max(1920), rankWidth: external_exports.number().min(0).max(300), rowStyle: external_exports.enum(["connected", "separated"]).default("connected"), rowArtwork: external_exports.boolean().default(false), detected: external_exports.boolean() });

// lib/scoreboard.ts
var id = external_exports.string().min(1).max(80);
var name = external_exports.string().trim().min(1).max(80);
var count = external_exports.number().int().min(0).max(1e4);
var points = external_exports.number().min(-1e5).max(1e5);
var rushThreshold = external_exports.number().int().min(0).max(1e5).optional();
var scoreResultSchema = external_exports.object({ teamId: id, rank: external_exports.number().int().min(1).max(100), kills: count, booyah: external_exports.number().int().min(0).max(1), sourcePoints: points.nullable(), placementPoints: external_exports.number().nonnegative().optional(), matchPoints: external_exports.number().nonnegative().optional(), rankVerified: external_exports.boolean().optional(), rankUncertain: external_exports.boolean().optional() });
var scoreMatchSchema = external_exports.object({ id, stageId: id, name: external_exports.string().max(120), source: external_exports.enum(["matchstats", "manual"]), sourceRecordId: external_exports.number().int().positive().optional(), enabled: external_exports.boolean(), importedAt: external_exports.number().int().nonnegative(), rows: external_exports.array(scoreResultSchema).min(1).max(100) }).superRefine((m, c) => {
  if (m.rows.filter((r) => r.booyah === 1).length !== 1) c.addIssue({ code: "custom", message: "M\u1ED9t tr\u1EADn c\u1EA7n \u0111\xFAng m\u1ED9t \u0111\u1ED9i BOOYAH." });
  if (new Set(m.rows.map((r) => r.teamId)).size !== m.rows.length) c.addIssue({ code: "custom", message: "M\u1ED9t \u0111\u1ED9i ch\u1EC9 \u0111\u01B0\u1EE3c xu\u1EA5t hi\u1EC7n m\u1ED9t l\u1EA7n trong m\u1ED9t tr\u1EADn." });
});
var scoreRuleSchema = external_exports.object({ mode: external_exports.enum(["source", "custom"]), killPoints: external_exports.number().min(0).max(100), placements: external_exports.array(external_exports.number().min(0).max(1e3)).min(1).max(100), tieBreak: external_exports.enum(["booyah-kills-last", "kills-booyah-last", "last-booyah-kills"]), confirmed: external_exports.boolean() });
var scoreBoardSchema = external_exports.object({ scheduleDesign: scheduleDesignSchema.optional(), id, name, totalLayout: external_exports.enum(["classic", "schedule"]).optional(), championRushPoints: rushThreshold, matchTemplate: scoreTemplateSchema.nullable().optional(), totalTemplate: scoreTemplateSchema.nullable().optional(), matchTypography: typographySchema.optional(), totalTypography: typographySchema.optional(), title: external_exports.string().max(120), subtitle: external_exports.string().max(120), panelColor: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/), textColor: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/), titleColor: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/), highlight: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/), stages: external_exports.array(external_exports.object({ id, name })).min(1).max(50), scope: external_exports.array(id).max(50), teams: external_exports.array(external_exports.object({ id, name: name.toUpperCase(), logo: teamLogoSchema, externalKeys: external_exports.array(id).max(100), adjustment: points })).max(100), matches: external_exports.array(scoreMatchSchema).max(200), rule: scoreRuleSchema }).superRefine((b, c) => {
  const issue = (message) => c.addIssue({ code: "custom", message });
  if (new Set(b.matches.map((m) => m.id)).size !== b.matches.length) issue("Match ID \u0111\xE3 c\xF3 trong gi\u1EA3i n\xE0y.");
  if (new Set(b.teams.map((t) => t.id)).size !== b.teams.length || new Set(b.stages.map((s) => s.id)).size !== b.stages.length) issue("M\xE3 \u0111\u1ED9i ho\u1EB7c v\xF2ng \u0111\u1EA5u b\u1ECB tr\xF9ng.");
  const keys = b.teams.flatMap((t) => t.externalKeys);
  if (new Set(keys).size !== keys.length) issue("M\u1ED9t \u0111\u1ED9i Match Stats kh\xF4ng th\u1EC3 gh\xE9p v\xE0o hai \u0111\u1ED9i.");
  if (b.scope.some((s) => !b.stages.some((x) => x.id === s))) issue("V\xF2ng \u0111\u1EA5u hi\u1EC3n th\u1ECB kh\xF4ng t\u1ED3n t\u1EA1i.");
  for (const m of b.matches) {
    if (!b.stages.some((s) => s.id === m.stageId)) issue("Tr\u1EADn thu\u1ED9c v\xF2ng \u0111\u1EA5u kh\xF4ng t\u1ED3n t\u1EA1i.");
    if (m.rows.some((r) => !b.teams.some((t) => t.id === r.teamId))) issue("\u0110\u1ED9i trong k\u1EBFt qu\u1EA3 kh\xF4ng t\u1ED3n t\u1EA1i.");
  }
});
var standingSchema = external_exports.object({ teamId: id, name: name.toUpperCase(), logo: teamLogoSchema, crown: external_exports.enum(["silver", "gold"]).optional(), booyah: count, kills: count, total: points, matches: count, lastRank: external_exports.number().min(1).max(101), adjustment: points, placementPoints: external_exports.number().nonnegative().default(0), position: external_exports.number().int().min(1).max(100) });
var publishedScoreSchema = external_exports.object({ scheduleDesign: scheduleDesignSchema.optional(), layout: external_exports.enum(["classic", "schedule"]).optional(), championRushPoints: rushThreshold, template: scoreTemplateSchema.nullable().optional(), typography: typographySchema.optional(), boardId: id, view: external_exports.enum(["total", "match"]).default("total"), matchId: external_exports.string().max(80).default(""), title: external_exports.string().max(120), subtitle: external_exports.string().max(120), panelColor: external_exports.string(), textColor: external_exports.string(), titleColor: external_exports.string(), highlight: external_exports.string(), rows: external_exports.array(standingSchema).max(100).transform(rankRows), publishedAt: external_exports.number().int().nonnegative(), matchCount: external_exports.number().int().nonnegative() });
var scoreboardsSchema = external_exports.object({ boards: external_exports.array(scoreBoardSchema).max(20), selectedId: external_exports.string().max(80), published: publishedScoreSchema.nullable(), publishedMatch: publishedScoreSchema.nullable().default(null) }).superRefine((s, c) => {
  if (new Set(s.boards.map((b) => b.id)).size !== s.boards.length) c.addIssue({ code: "custom", message: "Gi\u1EA3i b\u1EA3ng \u0111i\u1EC3m b\u1ECB tr\xF9ng." });
  if (s.selectedId && !s.boards.some((b) => b.id === s.selectedId)) c.addIssue({ code: "custom", message: "Gi\u1EA3i \u0111ang ch\u1ECDn kh\xF4ng t\u1ED3n t\u1EA1i." });
});
function rankRows(rows) {
  for (const row of rows) row.name = row.name.toUpperCase();
  rows.sort((a, b) => Number(a.matches === 0) - Number(b.matches === 0) || (a.matches === 0 && b.matches === 0 ? a.name.localeCompare(b.name, "vi", { sensitivity: "base" }) || a.teamId.localeCompare(b.teamId) : b.total - a.total || b.booyah - a.booyah || b.kills - a.kills || a.teamId.localeCompare(b.teamId)));
  let position = 0;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i], prev = rows[i - 1];
    if (r.matches === 0 || !prev || prev.total !== r.total || prev.kills !== r.kills || prev.booyah !== r.booyah) position = i + 1;
    r.position = position;
  }
  return rows;
}

// lib/drive-team-logos.ts
var idPattern = /^[A-Za-z0-9_-]{10,200}$/;
function parseDriveFolder(value) {
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw Error("D\xE1n link th\u01B0 m\u1EE5c Google Drive.");
  }
  if (url.protocol !== "https:" || url.hostname !== "drive.google.com" || url.username || url.password || url.port) throw Error("D\xF9ng link https://drive.google.com/drive/folders/...");
  const id3 = url.pathname.match(/\/folders\/([A-Za-z0-9_-]+)/)?.[1] || (url.pathname === "/open" ? url.searchParams.get("id") : null);
  if (!id3 || !idPattern.test(id3)) throw Error("Link c\u1EA7n tr\u1ECF t\u1EDBi th\u01B0 m\u1EE5c Drive, kh\xF4ng ph\u1EA3i m\u1ED9t \u1EA3nh.");
  const resourceKey = url.searchParams.get("resourcekey") || "";
  if (resourceKey && !idPattern.test(resourceKey)) throw Error("Resource key c\u1EE7a Drive kh\xF4ng h\u1EE3p l\u1EC7.");
  return { id: id3, resourceKey };
}

// lib/player-leaders.ts
var fieldSchema = external_exports.object({ x: external_exports.number().min(-1920).max(1920), y: external_exports.number().min(-1080).max(1080), width: external_exports.number().min(8).max(1920), height: external_exports.number().min(8).max(1080), size: external_exports.number().min(8).max(200), align: external_exports.enum(["left", "center", "right"]), color: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/).optional(), visible: external_exports.boolean() });
var portraitField = { x: 122, y: 4, width: 96, height: 82, size: 20, align: "center", visible: true };
var playerPortraitSchema = external_exports.string().max(300).refine((v) => !v || /^\/api\/media\/[a-f0-9-]+$/.test(v) || /^\/player-templates\/video-demo-portrait-[1-6]\.png$/.test(v), "\u1EA2nh tuy\u1EC3n th\u1EE7 kh\xF4ng h\u1EE3p l\u1EC7.");
var leaderDesignSchema = external_exports.object({ background: external_exports.string().max(300).refine((v) => !v || /^\/api\/media\/[a-f0-9-]+$/.test(v) || /^\/player-templates\/(red-gold-(elims|damage)|video-(elims|damage)-v2)\.png$/.test(v), "KV kh\xF4ng h\u1EE3p l\u1EC7."), x: external_exports.number().min(0).max(1920), y: external_exports.number().min(0).max(1080), stepX: external_exports.number().min(0).max(1920), stepY: external_exports.number().min(0).max(1080), color: external_exports.string().regex(/^#[a-fA-F0-9]{6}$/), font: external_exports.enum(fontFamilies), weight: external_exports.number().int().min(100).max(950), fields: external_exports.object({ rank: fieldSchema, logo: fieldSchema, portrait: fieldSchema.default(portraitField), team: fieldSchema, name: fieldSchema, elims: fieldSchema, damage: fieldSchema }) });
var leaderDesignsSchema = external_exports.object({ elims: leaderDesignSchema, damage: leaderDesignSchema });
var matchPlayerSchema = external_exports.object({ playerId: external_exports.string().min(1).max(80), name: external_exports.string().min(1).max(80), teamName: external_exports.string().min(1).max(80), kills: external_exports.number().int().min(0).max(1e4), damage: external_exports.number().int().min(0).max(1e6) });
var playerLeaderRowSchema = matchPlayerSchema.extend({ logo: teamLogoSchema, portrait: playerPortraitSchema.optional() });
var playerLeaderSnapshotSchema = external_exports.object({ matchId: external_exports.string().regex(/^\d{1,24}$/), matchName: external_exports.string().max(120), sourceRecordId: external_exports.number().int().min(-1).max(Number.MAX_SAFE_INTEGER).optional(), publishedAt: external_exports.number().int().nonnegative(), design: leaderDesignSchema.optional(), onAir: external_exports.boolean().default(true), players: external_exports.array(playerLeaderRowSchema).min(1).max(64) });
var portraitDriveFolderSchema = external_exports.string().trim().max(1e3).refine((value) => {
  if (!value) return true;
  try {
    parseDriveFolder(value);
    return true;
  } catch {
    return false;
  }
}, "Link th\u01B0 m\u1EE5c Drive kh\xF4ng h\u1EE3p l\u1EC7.");
var playerOverlaysSchema = external_exports.object({ portraitDriveFolderUrl: portraitDriveFolderSchema.optional(), portraits: external_exports.record(external_exports.string().min(1).max(80), playerPortraitSchema).refine((v) => Object.keys(v).length <= 500, "T\u1ED1i \u0111a 500 \u1EA3nh tuy\u1EC3n th\u1EE7.").optional(), designs: leaderDesignsSchema.optional(), elims: playerLeaderSnapshotSchema.nullable().default(null), damage: playerLeaderSnapshotSchema.nullable().default(null) }).default({ elims: null, damage: null });

// lib/matchstats.ts
var origin = "https://matchstats.sea.ffesports.com";
var matchIdSchema = external_exports.string().trim().regex(/^\d{1,24}$/, "Match ID ch\u1EC9 g\u1ED3m ch\u1EEF s\u1ED1, t\u1ED1i \u0111a 24 k\xFD t\u1EF1.");
function record(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) throw new Error("Match Stats tr\u1EA3 d\u1EEF li\u1EC7u kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng.");
  return v;
}
function integer(v, label, min = 0, max = 1e4) {
  if (typeof v !== "number" || !Number.isInteger(v) || v < min || v > max) throw new Error(`D\u1EEF li\u1EC7u ${label} kh\xF4ng h\u1EE3p l\u1EC7; ch\u01B0a nh\u1EADp \u0111i\u1EC3m.`);
  return v;
}
function sourcePlayerId(value) {
  if (typeof value === "number") return Number.isSafeInteger(value) && value >= 0 ? String(value) : null;
  return typeof value === "string" && /^\d{1,24}$/.test(value) ? value : null;
}
async function post(path2, body, timeoutMs = 2e4) {
  try {
    const response = await fetch(origin + "/api/match_stats/" + path2, { method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json", "Origin": origin, "Referer": origin + "/" }, body: JSON.stringify(body), signal: AbortSignal.timeout(timeoutMs), redirect: "manual", cache: "no-store" });
    if (response.status >= 300 && response.status < 400) throw new Error("Match Stats chuy\u1EC3n h\u01B0\u1EDBng y\xEAu c\u1EA7u. Th\u1EED l\u1EA1i sau.");
    if (response.status === 401 || response.status === 403) throw new Error("Match Stats y\xEAu c\u1EA7u quy\u1EC1n truy c\u1EADp. C\xF3 th\u1EC3 nh\u1EADp k\u1EBFt qu\u1EA3 th\u1EE7 c\xF4ng; kh\xF4ng c\xF3 \u0111i\u1EC3m n\xE0o \u0111\u01B0\u1EE3c t\u1EF1 c\u1ED9ng.");
    if (!response.ok) throw new Error("Match Stats ch\u01B0a ph\u1EA3n h\u1ED3i (" + response.status + "). Th\u1EED l\u1EA1i sau.");
    const raw = await response.text();
    if (raw.length > 1e7) throw new Error("D\u1EEF li\u1EC7u Match Stats qu\xE1 l\u1EDBn.");
    let json;
    try {
      json = JSON.parse(raw);
    } catch {
      throw new Error("Match Stats kh\xF4ng tr\u1EA3 JSON.");
    }
    const root = record(json);
    if (root.status !== "success") throw new Error(typeof root.msg === "string" ? "Match Stats: " + root.msg : "Kh\xF4ng l\u1EA5y \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u Match Stats.");
    return root;
  } catch (error) {
    if (error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError")) throw Error("Match Stats ph\u1EA3n h\u1ED3i ch\u1EADm. Gi\u1EEF s\u1ED1 li\u1EC7u h\u1EE3p l\u1EC7 g\u1EA7n nh\u1EA5t v\xE0 th\u1EED l\u1EA1i.");
    throw error;
  }
}
var AmbiguousMatchError = class extends Error {
  constructor(candidates) {
    super("Match ID c\xF3 nhi\u1EC1u b\u1EA3n k\u1EBFt qu\u1EA3. Ch\u1ECDn \u0111\xFAng event tr\u01B0\u1EDBc khi l\u1EA5y \u0111i\u1EC3m.");
    this.candidates = candidates;
  }
};
function normalizeLivePlayers(id3, payload) {
  const root = record(payload);
  if (root.status !== "success") throw Error("Match Stats ch\u01B0a tr\u1EA3 th\u1ED1ng k\xEA tuy\u1EC3n th\u1EE7 th\xE0nh c\xF4ng.");
  const md = record(root.data);
  const info = Array.isArray(md.match_info) ? md.match_info.map(record).find((x) => x.match_id === id3) : void 0;
  const group = Array.isArray(md.team_stats) ? md.team_stats.map(record).find((x) => x.match_id === id3) : void 0;
  if (!info || !group || !Array.isArray(group.team_stats) || !group.team_stats.length) throw Error("Ch\u01B0a c\xF3 th\u1ED1ng k\xEA tuy\u1EC3n th\u1EE7 \u0111\xFAng Match ID.");
  if (info.mode !== void 0 && info.mode !== 1) throw Error("Th\u1ED1ng k\xEA kh\xF4ng thu\u1ED9c tr\u1EADn Battle Royale.");
  const expectedTeams = typeof info.number_of_team === "number" ? integer(info.number_of_team, "s\u1ED1 \u0111\u1ED9i ngu\u1ED3n", 0, 1e3) : 0;
  if (expectedTeams > 0 && group.team_stats.length !== expectedTeams) throw Error("D\u1EEF li\u1EC7u ngu\u1ED3n ch\u01B0a \u0111\u1EE7 \u0111\u1ED9i. Gi\u1EEF l\u1EA7n c\u1EADp nh\u1EADt h\u1EE3p l\u1EC7 g\u1EA7n nh\u1EA5t.");
  const players = [];
  const seen = /* @__PURE__ */ new Set();
  for (const rawTeam of group.team_stats) {
    const team = record(rawTeam);
    if (!Array.isArray(team.player_data) || !team.player_data.length) throw Error("Ngu\u1ED3n c\xF2n thi\u1EBFu th\u1ED1ng k\xEA tuy\u1EC3n th\u1EE7 c\u1EE7a m\u1ED9t \u0111\u1ED9i. Ch\u01B0a c\u1EADp nh\u1EADt Top 5.");
    for (const rawPlayer of team.player_data) {
      const p = record(rawPlayer);
      const parsed = matchPlayerSchema.safeParse({ playerId: sourcePlayerId(p.player_id) || "", name: p.player_name, teamName: p.team_name || team.team_name, kills: p.kills, damage: p.damage });
      if (!parsed.success) throw Error("Ngu\u1ED3n c\xF3 UID, ELIMS ho\u1EB7c DAMAGE ch\u01B0a h\u1EE3p l\u1EC7. Ch\u01B0a c\u1EADp nh\u1EADt Top 5.");
      if (seen.has(parsed.data.playerId)) throw Error("Ngu\u1ED3n c\xF3 player ID tr\xF9ng. Ch\u01B0a c\u1EADp nh\u1EADt Top 5.");
      seen.add(parsed.data.playerId);
      players.push(parsed.data);
    }
  }
  const expectedPlayers = typeof info.number_of_player === "number" ? integer(info.number_of_player, "s\u1ED1 tuy\u1EC3n th\u1EE7 ngu\u1ED3n", 0, 1e3) : 0;
  if (expectedPlayers > 0 && players.length !== expectedPlayers) throw Error("Ngu\u1ED3n m\u1EDBi tr\u1EA3 " + players.length + "/" + expectedPlayers + " tuy\u1EC3n th\u1EE7. Gi\u1EEF l\u1EA7n c\u1EADp nh\u1EADt h\u1EE3p l\u1EC7 g\u1EA7n nh\u1EA5t.");
  return { players, expectedPlayers, name: typeof info.match_name === "string" ? info.match_name.slice(0, 120) : "" };
}
async function fetchLivePlayerStats(input, resultId) {
  const id3 = matchIdSchema.parse(input);
  const deadline = performance.now() + LIVE_SOURCE_BUDGET_MS;
  const remaining = () => {
    const time = Math.ceil(deadline - performance.now());
    if (time <= 0) throw Error("Match Stats ph\u1EA3n h\u1ED3i ch\u1EADm. Gi\u1EEF s\u1ED1 li\u1EC7u h\u1EE3p l\u1EC7 g\u1EA7n nh\u1EA5t v\xE0 th\u1EED l\u1EA1i.");
    return time;
  };
  const search = await post("search", { search_type: 1, param: [id3], field: "match", size: 100, page: 1, order_by: "-match_id", season_id: -1, event_id: -1 }, remaining());
  const data = record(search.data);
  const matches = Array.isArray(data.match_stats) ? data.match_stats.map(record).filter((m) => m.match_id === id3) : [];
  const candidates = matches.map((m) => ({ recordId: integer(m.single_match_id, "m\xE3 k\u1EBFt qu\u1EA3", -1, Number.MAX_SAFE_INTEGER), seasonId: integer(m.season_id, "season", -1, Number.MAX_SAFE_INTEGER), eventId: integer(m.event_id, "event", -1, Number.MAX_SAFE_INTEGER), startTime: typeof m.start_time === "number" ? m.start_time : 0, endTime: typeof m.end_time === "number" ? m.end_time : 0, name: typeof m.match_name === "string" ? m.match_name.slice(0, 120) : "" }));
  const unique2 = [...new Map(candidates.map((c) => [c.recordId, c])).values()];
  if (!unique2.length) throw new Error("Ch\u01B0a t\xECm th\u1EA5y tr\u1EADn tr\xEAn Match Stats. H\xE3y ki\u1EC3m tra Match ID ho\u1EB7c k\u1EBFt n\u1ED1i l\u1EA1i sau.");
  if (unique2.length > 1 && resultId === void 0) throw new AmbiguousMatchError(unique2);
  const chosen = resultId === void 0 ? unique2[0] : unique2.find((c) => c.recordId === resultId);
  if (!chosen) throw new Error("B\u1EA3n k\u1EBFt qu\u1EA3 \u0111\xE3 ch\u1ECDn kh\xF4ng thu\u1ED9c Match ID n\xE0y.");
  const found = matches.find((m) => m.single_match_id === chosen.recordId);
  if (found.mode !== 1) throw new Error("Ch\u1EC9 h\u1ED7 tr\u1EE3 tr\u1EADn Battle Royale.");
  const payload = await post("match_data", { match_ids: [id3], single_match_id: [chosen.recordId] }, remaining());
  remaining();
  const normalized = normalizeLivePlayers(id3, payload);
  remaining();
  return { id: id3, ...normalized, name: normalized.name || chosen.name, endTime: chosen.endTime, sourceRecordId: chosen.recordId, eventId: chosen.eventId, seasonId: chosen.seasonId };
}

// lib/live-team-roster.ts
function applyUidRoster(state, matchId, players) {
  if (state.matchId !== matchId) return { verified: false, message: "Roster kh\xE1c tr\u1EADn \u0111ang ch\u1EA1y." };
  state.authoritativeGroups.clear();
  state.rosterMatchId = null;
  const names = /* @__PURE__ */ new Map();
  for (const [id3, name2] of state.teams) {
    const key = teamNameKey(name2);
    names.set(key, [...names.get(key) || [], id3]);
  }
  const uidToName = /* @__PURE__ */ new Map();
  for (const p of players) {
    if (!/^\d{1,24}$/.test(p.playerId) || uidToName.has(p.playerId)) return { verified: false, message: "Roster UID kh\xF4ng duy nh\u1EA5t." };
    uidToName.set(p.playerId, teamNameKey(p.teamName));
  }
  const byGroup = /* @__PURE__ */ new Map();
  for (const player of state.players.values()) {
    const name2 = player.uid ? uidToName.get(player.uid) : void 0, ids = name2 ? names.get(name2) : void 0;
    if (!ids || ids.length !== 1) return { verified: false, message: "Ch\u1EDD UID/t\xEAn \u0111\u1ED9i kh\u1EDBp \u0111\u1EE7 roster c\u1EE7a tr\u1EADn." };
    const idsInGroup = byGroup.get(player.group) || /* @__PURE__ */ new Set();
    idsInGroup.add(ids[0]);
    byGroup.set(player.group, idsInGroup);
  }
  if (byGroup.size !== state.teams.size || [...byGroup.values()].some((ids) => ids.size !== 1)) return { verified: false, message: "Roster \u0111\u1ED9i ch\u01B0a \u0111\u1EE7 ho\u1EB7c m\xE2u thu\u1EABn UID." };
  const pairs = [...byGroup].map(([group, ids]) => [group, [...ids][0]]);
  if (new Set(pairs.map(([, id3]) => id3)).size !== state.teams.size) return { verified: false, message: "UID \u0111ang tr\u1ECF tr\xF9ng \u0111\u1ED9i." };
  state.authoritativeGroups = new Map(pairs);
  state.rosterMatchId = matchId;
  return { verified: true, message: "\u0110\xE3 x\xE1c minh " + pairs.length + " \u0111\u1ED9i b\u1EB1ng UID v\xE0 t\xEAn \u0111\u1ED9i c\u1EE7a \u0111\xFAng tr\u1EADn." };
}

// scripts/live-scoreboard-bridge.mjs
import { readFile, writeFile, readdir, stat, mkdir, open } from "node:fs/promises";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { randomUUID } from "node:crypto";
import { StringDecoder } from "node:string_decoder";

// lib/live-presentation.ts
var liveAlignmentSchema = external_exports.object({ detected: external_exports.boolean(), rowArtwork: external_exports.boolean().optional(), groups: external_exports.array(external_exports.object({ x: external_exports.number().min(0).max(1920), y: external_exports.number().min(0).max(1080), width: external_exports.number().min(40).max(1920), rowHeight: external_exports.number().min(8).max(200), rowStep: external_exports.number().min(8).max(200), rows: external_exports.number().int().min(1).max(100) })).min(1).max(4), columns: external_exports.object({ total: external_exports.number().min(0).max(1).default(0.6), logo: external_exports.number().min(0).max(1), teamName: external_exports.number().min(0).max(1), slot: external_exports.number().min(0).max(1), elims: external_exports.number().min(0).max(1), aliveCount: external_exports.number().min(0).max(1), damage: external_exports.number().min(0).max(1), placement: external_exports.number().min(0).max(1) }) });

// lib/live-board.ts
var LIVE_COMPACT_KV = "/live-board-templates/standing-compact-neon-14-v1.png";
var LIVE_TEST_KV = "/live-board-templates/test-red-gold-v1.png";
var id2 = external_exports.string().regex(/^\d{1,24}$/);
var nullableInt = (max) => external_exports.number().int().min(0).max(max).nullable();
var ratio = external_exports.number().min(0).max(1);
var rgb = external_exports.tuple([external_exports.number().int().min(0).max(255), external_exports.number().int().min(0).max(255), external_exports.number().int().min(0).max(255)]);
var liveTeamSchema = external_exports.object({ teamId: external_exports.string().max(80).nullable().default(null), teamName: external_exports.string().trim().min(1).max(80), slot: external_exports.number().int().min(1).max(100).nullable().default(null), elims: nullableInt(1e4), aliveCount: nullableInt(100), aliveStates: external_exports.array(external_exports.enum(["alive", "knocked", "dead", "unknown"])).min(1).max(8).nullable().default(null), damage: nullableInt(1e6).default(null), placement: external_exports.number().int().min(1).max(100).nullable().default(null) });
var livePacketSchema = external_exports.object({ sessionId: external_exports.string().uuid(), configId: external_exports.string().uuid(), sequence: external_exports.number().int().min(0).max(Number.MAX_SAFE_INTEGER), matchId: id2, detectedMatchId: id2.nullable(), source: external_exports.enum(["windows-ocr", "normalized-file", "game-log"]), isReplay: external_exports.boolean(), capturedAt: external_exports.number().int().positive(), matchStartedAt: external_exports.number().int().positive().nullable().default(null), rosterProof: external_exports.object({ capacity: external_exports.number().int().min(1).max(8), groups: external_exports.array(external_exports.object({ groupId: external_exports.number().int().min(0).max(1e3), count: external_exports.number().int().min(1).max(8) })).min(1).max(100) }).nullable().default(null), sourceEventAt: external_exports.number().int().positive().nullable().default(null), captureSpanMs: external_exports.number().min(0).max(4e3).default(0), expectedTeams: external_exports.number().int().min(1).max(100), complete: external_exports.literal(true), teams: external_exports.array(liveTeamSchema).min(1).max(100), remainingTeams: nullableInt(100).default(null), remainingPlayers: nullableInt(1e3).default(null) }).superRefine((p, ctx) => {
  if (p.teams.length !== p.expectedTeams) ctx.addIssue({ code: "custom", message: "Ch\u01B0a \u0111\u1ECDc \u0111\u1EE7 s\u1ED1 \u0111\u1ED9i \u0111\xE3 x\xE1c nh\u1EADn." });
  if (p.remainingTeams !== null && p.remainingTeams > p.teams.length) ctx.addIssue({ code: "custom", message: "Game b\xE1o c\xF2n nhi\u1EC1u \u0111\u1ED9i h\u01A1n s\u1ED1 h\xE0ng \u0111\xE3 \u0111\u1ECDc. Thi\u1EBFu ph\u1EA7n b\u1EA3ng." });
  const keys = p.teams.map((t) => t.teamId || teamNameKey(t.teamName));
  if (new Set(keys).size !== keys.length) ctx.addIssue({ code: "custom", message: "\u0110\u1ED9i b\u1ECB tr\xF9ng trong snapshot." });
  const slots = p.teams.map((t) => t.slot).filter((s) => s !== null);
  if (new Set(slots).size !== slots.length) ctx.addIssue({ code: "custom", message: "Slot b\u1ECB tr\xF9ng." });
  for (const team of p.teams) {
    if (team.aliveStates && !team.aliveStates.includes("unknown") && team.aliveCount !== null && team.aliveStates.filter((s) => s === "alive" || s === "knocked").length !== team.aliveCount) ctx.addIssue({ code: "custom", message: "ALIVE kh\xF4ng kh\u1EDBp tr\u1EA1ng th\xE1i tuy\u1EC3n th\u1EE7." });
  }
  if (p.teams.every((t) => t.aliveCount !== null)) {
    if (p.remainingPlayers !== null && p.teams.reduce((n, t) => n + t.aliveCount, 0) !== p.remainingPlayers) ctx.addIssue({ code: "custom", message: "T\u1ED5ng ALIVE kh\xF4ng kh\u1EDBp b\u1ED9 \u0111\u1EBFm trong game. C\xF3 th\u1EC3 thi\u1EBFu trang ho\u1EB7c \u0111\u1ECDc sai v\u1EA1ch." });
    if (p.remainingTeams !== null && p.teams.filter((t) => t.aliveCount > 0).length !== p.remainingTeams) ctx.addIssue({ code: "custom", message: "S\u1ED1 \u0111\u1ED9i c\xF2n ng\u01B0\u1EDDi kh\xF4ng kh\u1EDBp b\u1ED9 \u0111\u1EBFm game." });
  }
});
var liveLayoutSchema = external_exports.object({ rowTop: ratio.default(275 / 1009), rowStep: ratio.default(56.7 / 1009), rowHeight: ratio.default(38 / 1009), visibleRows: external_exports.number().int().min(1).max(24).default(12), teamX: ratio.default(1680 / 1920), teamWidth: ratio.default(90 / 1920), elimsX: ratio.default(1788 / 1920), elimsWidth: ratio.default(50 / 1920), barXs: external_exports.array(ratio).min(1).max(8).default([1865 / 1920, 1878 / 1920, 1892 / 1920, 1905 / 1920]), barY: ratio.default(19 / 1009), aliveColors: external_exports.array(rgb).min(1).max(8).default([[255, 174, 0]]), deadColors: external_exports.array(rgb).min(1).max(8).default([[128, 98, 28]]), colorTolerance: external_exports.number().min(1).max(100).default(75), readAlive: external_exports.boolean().default(true) });
var liveBoardSettingsSchema = external_exports.object({ configId: external_exports.string().uuid(), scoreBoardId: external_exports.string().max(80).default(""), enabled: external_exports.boolean().default(false), matchId: external_exports.union([id2, external_exports.literal("")]).default(""), mode: external_exports.enum(["live", "replay"]).default("live"), followGame: external_exports.boolean().default(true), adapter: external_exports.enum(["windows-ocr", "normalized-file", "game-log"]).default("game-log"), expectedTeams: external_exports.number().int().min(1).max(100).default(12), rosterConfirmed: external_exports.boolean().default(false), sourcePath: external_exports.string().max(500).default(""), layout: liveLayoutSchema.default({}), design: external_exports.object({ autoAlign: external_exports.boolean().default(true), alignment: liveAlignmentSchema.nullable().default(null), title: external_exports.string().max(100).default("B\u1EA2NG \u0110I\u1EC2M TRONG TR\u1EACN"), kv: external_exports.string().max(300).refine((s) => !s || s === LIVE_TEST_KV || s === LIVE_COMPACT_KV || s === "/live-board-templates/standing-compact-v1.png" || /^\/api\/media\/[a-f0-9-]+$/.test(s)).default(""), x: external_exports.number().min(0).max(1920).default(300), y: external_exports.number().min(0).max(1080).default(180), width: external_exports.number().min(300).max(1920).default(1320), rowHeight: external_exports.number().min(20).max(120).default(54), gap: external_exports.number().min(0).max(40).default(6), color: external_exports.string().regex(/^#[a-f0-9]{6}$/i).default("#ffffff"), fontSize: external_exports.number().min(10).max(70).default(28), showHeader: external_exports.boolean().default(true), showSlot: external_exports.boolean().default(false), showAlive: external_exports.boolean().default(true), showElims: external_exports.boolean().default(true), showTotal: external_exports.boolean().default(true), showDamage: external_exports.boolean().default(false), showPlacement: external_exports.boolean().default(false) }).default({}) });

// lib/live-board-ocr.ts
function parseOcrInteger(text, zeroShape = false, oneShape = false) {
  const value = text.trim();
  if (zeroShape && oneShape) return null;
  if (/^\d{1,4}$/.test(value)) {
    if (zeroShape && Number(value) !== 0 || oneShape && Number(value) !== 1) return null;
    return Number(value);
  }
  if (zeroShape && (!value || /^[Oo]$/.test(value))) return 0;
  return oneShape && (!value || /^[Il]$/.test(value)) ? 1 : null;
}
function colorAlive(pixels, settings) {
  if (!settings.layout.readAlive) return null;
  let alive = 0;
  for (const pixel of pixels) {
    const distance = (color2) => Math.hypot(pixel.r - color2[0], pixel.g - color2[1], pixel.b - color2[2]);
    const yes = Math.min(...settings.layout.aliveColors.map(distance)), no = Math.min(...settings.layout.deadColors.map(distance));
    if (Math.min(yes, no) > settings.layout.colorTolerance || Math.abs(yes - no) < 20) return null;
    if (yes < no) alive++;
  }
  return pixels.length === settings.layout.barXs.length ? alive : null;
}
function parseOcrFrame(frame, settings, registered) {
  const errors = [];
  if (!frame.headerDetected) errors.push("Ch\u01B0a th\u1EA5y \u0111\u1EE7 ti\xEAu \u0111\u1EC1 TEAM / ELIMS / ALIVE. B\u1EADt L v\xE0 gi\u1EEF game \u1EDF ph\xEDa tr\u01B0\u1EDBc.");
  const rows = frame.rows.map((row) => {
    const name2 = row.teamName.trim();
    const matched = registered.filter((team) => [team.name, team.abbreviation || ""].some((value) => value && teamNameKey(value) === teamNameKey(name2)));
    const elims = parseOcrInteger(row.elimsText, row.zeroShape, row.oneShape), aliveCount = colorAlive(row.pixels, settings);
    if (!name2) errors.push("C\xF3 h\xE0ng ch\u01B0a \u0111\u1ECDc \u0111\u01B0\u1EE3c t\xEAn \u0111\u1ED9i.");
    if (matched.length > 1) errors.push("T\xEAn \u0111\u1ED9i tr\xF9ng danh s\xE1ch: " + name2);
    if (elims === null) errors.push("Ch\u01B0a \u0111\u1ECDc ch\u1EAFc ELIMS: " + (name2 || "h\xE0ng tr\u1ED1ng"));
    if (settings.layout.readAlive && aliveCount === null) errors.push("M\xE0u ALIVE ch\u01B0a x\xE1c nh\u1EADn: " + name2);
    return { teamName: name2, teamId: matched.length === 1 ? matched[0].id : null, slot: null, elims, aliveCount, aliveStates: null, damage: null, placement: null };
  });
  const nonempty = rows.filter((row) => row.teamName);
  if (nonempty.length !== settings.expectedTeams) errors.push("\u0110ang \u0111\u1ECDc " + nonempty.length + "/" + settings.expectedTeams + " \u0111\u1ED9i. Kh\xF4ng ph\xE1t b\u1EA3ng thi\u1EBFu ph\u1EA7n.");
  if (frame.remainingTeams !== null && frame.remainingTeams > nonempty.length) errors.push("Game c\xF2n " + frame.remainingTeams + " \u0111\u1ED9i nh\u01B0ng khung ch\u1EC9 c\xF3 " + nonempty.length + " h\xE0ng.");
  if (frame.remainingPlayers !== null && nonempty.every((row) => row.aliveCount !== null) && nonempty.reduce((n, row) => n + row.aliveCount, 0) !== frame.remainingPlayers) errors.push("T\u1ED5ng v\u1EA1ch ALIVE kh\xF4ng kh\u1EDBp s\u1ED1 ng\u01B0\u1EDDi c\u1EE7a game.");
  return { rows: nonempty, errors };
}
function packetFromOcr(frame, settings, registered, sessionId2, sequence2, detectedMatchId, clockOffset = 0) {
  const parsed = parseOcrFrame(frame, settings, registered);
  const errors = [...parsed.errors];
  if (frame.replayHint && settings.mode === "live") errors.push("C\u1EEDa s\u1ED5 c\xF3 thanh ph\xE1t replay; kh\xF4ng nh\u1EADn th\xE0nh d\u1EEF li\u1EC7u live.");
  if (!settings.rosterConfirmed) errors.push("Ch\u01B0a x\xE1c nh\u1EADn t\u1ED5ng s\u1ED1 \u0111\u1ED9i c\u1EE7a tr\u1EADn.");
  if (!settings.matchId) errors.push("Ch\u01B0a ch\u1ECDn Match ID.");
  if (settings.mode === "live" && detectedMatchId !== settings.matchId) errors.push("Match ID log phi\xEAn client ch\u01B0a kh\u1EDBp; ch\u01B0a x\xE1c nh\u1EADn live.");
  const diagnostic = { rows: parsed.rows, visibleRows: frame.rows.length, remainingTeams: frame.remainingTeams, remainingPlayers: frame.remainingPlayers, processingMs: frame.processingMs, detectedMatchId, processId: frame.processId, width: frame.width, height: frame.height, source: "windows-ocr", mode: settings.mode, replayHint: frame.replayHint || false, errors: errors.slice(0, 8) };
  if (errors.length) return { packet: null, diagnostic, message: errors.slice(0, 3).join(" ") };
  const result = livePacketSchema.safeParse({ sessionId: sessionId2, configId: settings.configId, sequence: sequence2, matchId: settings.matchId, detectedMatchId, source: "windows-ocr", isReplay: settings.mode === "replay", capturedAt: Math.round(frame.capturedAt + clockOffset), sourceEventAt: null, captureSpanMs: 0, expectedTeams: settings.expectedTeams, complete: true, teams: parsed.rows, remainingTeams: frame.remainingTeams, remainingPlayers: frame.remainingPlayers });
  if (!result.success) return { packet: null, diagnostic, message: result.error.issues.map((issue) => issue.message).join(" ").slice(0, 500) };
  return { packet: result.data, diagnostic, message: "" };
}
function parseLosslessJson(text) {
  return JSON.parse(text.replace(/^\uFEFF/, ""), (_key, value, context) => {
    if (typeof value === "number" && Number.isInteger(value) && !Number.isSafeInteger(value)) {
      if (!context?.source) throw Error("C\u1EA7n Node h\u1ED7 tr\u1EE3 JSON source context \u0111\u1EC3 gi\u1EEF ID d\xE0i.");
      return context.source;
    }
    return value;
  });
}

// lib/live-board-auto.ts
function followsGame(settings) {
  return settings.followGame && settings.adapter === "game-log" && settings.mode === "live";
}
function sourceRoster(state) {
  if (!state.matchId || !state.matchStartedAt || state.sourceReplay || !state.teams.size || state.scores.size !== state.teams.size || ![...state.teams.keys()].every((id3) => state.scores.has(id3)) || !state.playersPerTeam) return null;
  const groups = /* @__PURE__ */ new Map();
  for (const player of state.players.values()) groups.set(player.group, (groups.get(player.group) || 0) + 1);
  if (groups.size !== state.teams.size || [...groups.values()].some((size) => size < 1 || size > state.playersPerTeam)) return null;
  return { capacity: state.playersPerTeam, groups: [...groups].map(([groupId, count2]) => ({ groupId, count: count2 })) };
}
function sourceSettings(state, settings) {
  if (!followsGame(settings)) return settings;
  if (!sourceRoster(state)) return null;
  return { ...settings, matchId: state.matchId, expectedTeams: state.teams.size, rosterConfirmed: true };
}

// lib/live-status.ts
function unique(options2) {
  return [...new Map(options2.map((ids) => {
    const sorted = [...new Set(ids)].sort();
    return [sorted.join(","), sorted];
  })).values()];
}
function tracker(s) {
  return s.lifeTracker ??= { groups: /* @__PURE__ */ new Map(), knocks: /* @__PURE__ */ new Map(), rescues: /* @__PURE__ */ new Set() };
}
function options(s, group) {
  const t = tracker(s);
  return t.groups.get(group) ?? [[...s.players].filter(([id3, p]) => p.group === group && s.playerStates.get(id3) === "knocked" && !s.deadPlayers.has(id3)).map(([id3]) => id3)];
}
function set(s, group, next) {
  const t = tracker(s), values = unique(next);
  t.groups.set(group, values);
  for (const [id3, p] of s.players) {
    if (p.group !== group || s.deadPlayers.has(id3)) continue;
    if (values.every((ids) => ids.includes(id3))) s.playerStates.set(id3, "knocked");
    else if (values.every((ids) => !ids.includes(id3))) s.playerStates.set(id3, "alive");
  }
}
function updateLife(s, event, id3, at, key) {
  const player = s.players.get(id3);
  if (!player) return false;
  const t = tracker(s), group = player.group;
  let current = options(s, group);
  if (event === "knock") {
    const previous = t.knocks.get(id3);
    if (previous && (previous.key === key || key.startsWith("secondary:") && at >= previous.at && at - previous.at < 1e3)) return false;
    t.knocks.set(id3, { at, key });
    const compatible = current.filter((ids) => !ids.includes(id3));
    if (compatible.length) current = compatible;
    set(s, group, current.map((ids) => [...ids, id3]));
    return true;
  }
  if (event === "recover" || event === "death") {
    t.knocks.delete(id3);
    set(s, group, current.map((ids) => ids.filter((x) => x !== id3)));
    return true;
  }
  if (t.rescues.has(key) || s.deadPlayers.has(id3)) return false;
  const helperAlive = current.filter((ids) => !ids.includes(id3));
  if (helperAlive.length) current = helperAlive;
  const next = current.flatMap((ids) => ids.filter((target) => target !== id3 && !s.deadPlayers.has(target)).map((target) => ids.filter((x) => x !== target)));
  if (!next.length) return false;
  t.rescues.add(key);
  set(s, group, next);
  return true;
}
function aggregateLife(s, group, members, capacity) {
  const current = s.lifeTracker?.groups.get(group);
  if (!current?.length) return null;
  const valid = current.map((ids) => ids.filter((id3) => !s.deadPlayers.has(id3))), counts = valid.map((ids) => ids.length), min = Math.min(...counts), max = Math.max(...counts);
  if (min === max) {
    const chosen = new Set(valid[0]);
    return Array.from({ length: capacity }, (_, i) => {
      const p = members[i];
      if (!p) return "unknown";
      return !p[1].alive ? "dead" : chosen.has(p[0]) ? "knocked" : "alive";
    });
  }
  const dead = members.filter(([, p]) => !p.alive).length;
  return [...Array(Math.max(0, capacity - dead - max)).fill("alive"), ...Array(min).fill("knocked"), ...Array(max - min).fill("unknown"), ...Array(dead).fill("dead")].slice(0, capacity);
}

// lib/live-board-gamelog.ts
function createGameLogState() {
  return { lifeTracker: void 0, authoritativeGroups: /* @__PURE__ */ new Map(), rosterMatchId: null, teams: /* @__PURE__ */ new Map(), scores: /* @__PURE__ */ new Map(), previousScores: /* @__PURE__ */ new Map(), players: /* @__PURE__ */ new Map(), playerStates: /* @__PURE__ */ new Map(), groupToTeam: /* @__PURE__ */ new Map(), mappingVotes: /* @__PURE__ */ new Map(), currentGroup: null, pendingScoringTeam: null, pendingScoringAt: 0, pendingScoringFrame: null, killEvents: [], killCoverageComplete: false, initialScoreTotal: null, deadPlayers: /* @__PURE__ */ new Set(), playersPerTeam: null, matchStartedAt: null, sourceReplay: false, openingFlightSeen: false, matchId: null, sampleAt: 0, teamInitAt: 0, dirty: false, diagnostic: "Ch\u1EDD log tr\u1EADn c\u1EE7a Free Fire." };
}
function eventTime(line) {
  const m = line.match(/^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d(?:\.\d+)?)\]/);
  return m ? Date.parse(m[1].replace(" ", "T")) : 0;
}
function frameKey(line) {
  const m = line.match(/^\[([^\]]+)\]\[(\d+)\]\[(\d+)\]/);
  return m ? m[1].slice(0, 10) + ":" + m[2] + ":" + m[3] : null;
}
function resetMatch(s) {
  Object.assign(s, createGameLogState());
}
function refreshMappings(s) {
  s.groupToTeam.clear();
  const candidates = [...s.mappingVotes].flatMap(([group, votes]) => {
    const sorted = [...votes].sort((a, b) => b[1] - a[1]);
    return sorted[0] && sorted[0][1] >= 2 && sorted[0][1] > (sorted[1]?.[1] ?? 0) ? [{ group, team: sorted[0][0], votes: sorted[0][1] }] : [];
  });
  for (const candidate of candidates) {
    const rivals = candidates.filter((c) => c.team === candidate.team && c.group !== candidate.group);
    if (rivals.every((c) => c.votes < candidate.votes)) s.groupToTeam.set(candidate.group, candidate.team);
  }
}
function verifyCoverage(s) {
  if (s.killCoverageComplete || s.initialScoreTotal === null || !s.teams.size) return;
  const groupSizes = /* @__PURE__ */ new Map();
  for (const player of s.players.values()) groupSizes.set(player.group, (groupSizes.get(player.group) || 0) + 1);
  if (groupSizes.size !== s.teams.size || ![...groupSizes.values()].every((size) => size >= 1 && size <= (s.playersPerTeam ?? 4))) return;
  if (s.openingFlightSeen) {
    s.killCoverageComplete = true;
    return;
  }
  if ([...s.scores.values()].reduce((sum, value) => sum + value, 0) !== s.initialScoreTotal) return;
  let kills = 0;
  for (const event of s.killEvents) {
    const victim = s.players.get(event.victim), killer = s.players.get(event.killer);
    if (event.killer === "0") continue;
    if (!victim || !killer) return;
    if (victim.group !== killer.group) kills++;
  }
  if (kills === s.initialScoreTotal) s.killCoverageComplete = true;
}
function flushScores(s) {
  const g = s.currentGroup;
  if (!g) return;
  s.currentGroup = null;
  if (!s.teams.size || g.values.size !== s.teams.size || ![...s.teams.keys()].every((id3) => g.values.has(id3))) return;
  if (!s.previousScores.size) s.initialScoreTotal = [...g.values.values()].reduce((sum, value) => sum + value, 0);
  const changed = [...g.values].filter(([id3, value]) => value - (s.previousScores.get(id3) ?? value) === 1);
  const allChanged = [...g.values].filter(([id3, value]) => value !== (s.previousScores.get(id3) ?? value));
  s.pendingScoringTeam = changed.length === 1 && allChanged.length === 1 ? changed[0][0] : null;
  s.pendingScoringAt = eventTime("[" + g.at + "]");
  s.pendingScoringFrame = g.frame;
  s.previousScores = new Map(g.values);
  s.scores = new Map(g.values);
  verifyCoverage(s);
  s.sampleAt = eventTime("[" + g.at + "]");
  s.dirty = true;
}
function consumeGameLogLine(s, line) {
  if (!line) return false;
  const at = eventTime(line), frame = frameKey(line);
  let flushed = false;
  const score = line.match(/^\[([^\]]+)\].*OnTeamScoreChanged -> TeamID: (\d+) TeamScore: (\d+)/);
  if (score) {
    const key = frame || score[1];
    if (s.currentGroup && (s.currentGroup.key !== key || s.currentGroup.values.has(+score[2]))) flushScores(s);
    if (!s.currentGroup) s.currentGroup = { key, at: score[1], frame, values: /* @__PURE__ */ new Map() };
    s.currentGroup.values.set(+score[2], +score[3]);
    if (s.teams.size && s.currentGroup.values.size === s.teams.size) {
      flushScores(s);
      return true;
    }
    return false;
  }
  if (s.currentGroup && (!frame || frame !== s.currentGroup.frame)) {
    const before = s.scores;
    flushScores(s);
    flushed = s.scores !== before;
  }
  if (/\bOnReplayStarted\b/.test(line)) {
    resetMatch(s);
    s.sourceReplay = true;
    s.diagnostic = "Replay b\u1EAFt \u0111\u1EA7u; \u0111ang \u0111\u1ECDc team t\u1EEB log.";
    return true;
  }
  const enter = line.match(/EventTypeEnterGame\s+(\{.*\})/);
  if (enter) {
    const id3 = enter[1].match(/"match_id"\s*:\s*"?(\d{1,24})/);
    if (id3 && s.matchId !== id3[1]) {
      const replay = s.sourceReplay && !s.matchId;
      resetMatch(s);
      s.sourceReplay = replay;
      s.matchId = id3[1];
      s.matchStartedAt = at || null;
      const mode = enter[1].match(/"group_mode"\s*:\s*(\d+)/)?.[1];
      s.playersPerTeam = mode === "3" ? 4 : mode === "2" ? 2 : mode === "1" ? 1 : null;
      s.diagnostic = "\u0110\xE3 nh\u1EADn Match ID t\u1EEB Player.log.";
      return true;
    }
  }
  const flight = line.match(/TeamFlightMoveAnimSync MarkState state:StartSkyDrivingFromLevel, startTime:([\d.]+)/);
  if (flight && !s.sourceReplay && !s.killEvents.length && s.matchStartedAt && at >= s.matchStartedAt && at - s.matchStartedAt <= 6e4 && Number(flight[1]) >= 0 && Number(flight[1]) <= 45) {
    s.openingFlightSeen = true;
    verifyCoverage(s);
    return true;
  }
  const init = line.match(/OnTeamScoreInited -> TeamName: (.*?) TeamID: (\d+)\s*$/);
  if (init) {
    if (!s.teams.size) s.teamInitAt = at;
    const id3 = +init[2], old = s.teams.get(id3);
    if (old && old !== init[1].trim()) {
      s.diagnostic = "T\xEAn team thay \u0111\u1ED5i trong c\xF9ng phi\xEAn; c\u1EA7n x\xE1c minh tr\u1EADn.";
      return true;
    }
    s.teams.set(id3, init[1].trim());
    return true;
  }
  const join2 = line.match(/\bPlayer Join,\s*(\d+),\s*(\d+),\s*(.*),(?:False|True)(\d+)\s*$/);
  const player = line.match(/\[UIModelSpectator\] AddPlayer id(\d+),name(.*),gsTeam(\d+)\s*$/) || (join2 ? ["", join2[2], join2[3], join2[4]] : null);
  if (player) {
    s.players.set(player[1], { group: +player[3], alive: !s.deadPlayers.has(player[1]), uid: join2 ? join2[1] : s.players.get(player[1])?.uid });
    verifyCoverage(s);
    return true;
  }
  const knock = line.match(/\bPlayer '(\d+)' Knock Down\b/) || line.match(/\bTeammate (\d+) Knock Down\b/);
  if (knock) {
    const id3 = knock[1];
    if (!s.deadPlayers.has(id3)) {
      updateLife(s, "knock", id3, at, (line.includes("Teammate ") ? "secondary:" : "primary:") + (frame || String(at)));
      s.playerStates.set(id3, "knocked");
      const p = s.players.get(id3);
      if (p) p.alive = true;
      s.sampleAt = at || s.sampleAt;
      s.dirty = true;
    }
    return true;
  }
  const getUp = line.match(/\bPlayer '(\d+)' (?:Get Up|Stand Up|Recovered)\b/) || line.match(/\bTeammate (\d+) (?:Get Up|Stand Up|Recovered)\b/);
  if (getUp) {
    const id3 = getUp[1];
    if (!s.deadPlayers.has(id3)) {
      updateLife(s, "recover", id3, at, frame || String(at));
      s.playerStates.set(id3, "alive");
      const p = s.players.get(id3);
      if (p) p.alive = true;
      s.sampleAt = at || s.sampleAt;
      s.dirty = true;
    }
    return true;
  }
  const rescue = line.match(/LogPlayerReplayEvent Player:(\d+) Event:4\s*$/);
  if (rescue) {
    const changed = updateLife(s, "rescue", rescue[1], at, (frame || String(at)) + ":" + rescue[1]);
    if (changed) {
      s.sampleAt = at || s.sampleAt;
      s.dirty = true;
    }
    return changed;
  }
  const dead = line.match(/Player (\d+) Dead, killed by (\d+)/);
  if (dead) {
    const id3 = dead[1], killer = dead[2], victim = s.players.get(id3), attacker = s.players.get(killer);
    const duplicate = s.deadPlayers.has(id3);
    updateLife(s, "death", id3, at, frame || String(at));
    s.deadPlayers.add(id3);
    s.playerStates.set(id3, "dead");
    if (victim) victim.alive = false;
    if (!duplicate) {
      const elapsed = at - s.pendingScoringAt;
      const sameEvent = frame && s.pendingScoringFrame ? frame === s.pendingScoringFrame : elapsed >= 0 && elapsed <= 500;
      s.killEvents.push({ victim: id3, killer, scoreTeam: sameEvent ? s.pendingScoringTeam : null });
      if (attacker && victim && attacker.group !== victim.group && s.pendingScoringTeam !== null && sameEvent) {
        const votes = s.mappingVotes.get(attacker.group) || /* @__PURE__ */ new Map();
        votes.set(s.pendingScoringTeam, (votes.get(s.pendingScoringTeam) || 0) + 1);
        s.mappingVotes.set(attacker.group, votes);
        refreshMappings(s);
      }
    }
    s.pendingScoringTeam = null;
    verifyCoverage(s);
    s.sampleAt = at || s.sampleAt;
    s.dirty = true;
    return true;
  }
  const revive = line.match(/Revive Player (\d+)/);
  if (revive) {
    updateLife(s, "recover", revive[1], at, frame || String(at));
    s.deadPlayers.delete(revive[1]);
    s.playerStates.set(revive[1], "alive");
    const old = s.players.get(revive[1]);
    if (old) old.alive = true;
    s.sampleAt = at || s.sampleAt;
    s.dirty = true;
    return true;
  }
  return flushed;
}
function gameLogSnapshot(s, settings, registered, sessionId2, sequence2, now = Date.now(), requireUidIdentity = false) {
  const automatic = followsGame(settings), selection = sourceSettings(s, settings);
  if (selection) settings = selection;
  const errors = [];
  if (automatic && !selection) errors.push("Ch\u1EDD client ghi \u0111\u1EE7 roster v\xE0 scoreboard c\u1EE7a tr\u1EADn.");
  if (!s.teams.size || s.scores.size !== s.teams.size) errors.push("Ch\u01B0a c\xF3 snapshot TeamScore \u0111\u1EA7y \u0111\u1EE7.");
  if (s.teams.size !== settings.expectedTeams) errors.push("Log c\xF3 " + s.teams.size + "/" + settings.expectedTeams + " team; ki\u1EC3m tra l\u1EA1i s\u1ED1 \u0111\u1ED9i.");
  if (!settings.rosterConfirmed) errors.push("Ch\u01B0a x\xE1c nh\u1EADn t\u1ED5ng s\u1ED1 team.");
  if (!settings.matchId) errors.push("Ch\u01B0a ch\u1ECDn Match ID.");
  if (settings.mode === "live" && s.matchId !== settings.matchId) errors.push("Match ID trong Player.log kh\xE1c tr\u1EADn \u0111ang ch\u1ECDn.");
  const identity = requireUidIdentity ? s.authoritativeGroups : s.groupToTeam;
  const identityReady = !requireUidIdentity || s.rosterMatchId === s.matchId && identity.size === s.teams.size;
  if (!identityReady) errors.push("Ch\u1EDD x\xE1c minh UID/t\xEAn \u0111\u1ED9i c\u1EE7a \u0111\xFAng tr\u1EADn; kh\xF4ng d\xF9ng gh\xE9p suy lu\u1EADn \u0111\u1EC3 ph\xE1t s\u1ED1 li\u1EC7u.");
  const kills = /* @__PURE__ */ new Map(), incomplete = /* @__PURE__ */ new Set();
  let unknownKiller = false;
  for (const event of s.killEvents) {
    const victim = s.players.get(event.victim), killer = s.players.get(event.killer);
    if (!killer) {
      if (event.killer !== "0") unknownKiller = true;
      continue;
    }
    if (!victim) {
      incomplete.add(killer.group);
      continue;
    }
    if (killer.group !== victim.group) kills.set(killer.group, (kills.get(killer.group) || 0) + 1);
  }
  const eventTeamKills = /* @__PURE__ */ new Map();
  let unresolvedEventTeam = false;
  for (const event of s.killEvents) {
    const victim = s.players.get(event.victim), killer = s.players.get(event.killer);
    if (event.killer === "0" || event.killer === event.victim) continue;
    if (!victim || !killer) {
      unresolvedEventTeam = true;
      continue;
    }
    if (victim.group === killer.group) continue;
    const team = identity.get(killer.group) ?? (requireUidIdentity ? null : event.scoreTeam);
    if (team === void 0 || team === null || !s.teams.has(team)) {
      unresolvedEventTeam = true;
      continue;
    }
    eventTeamKills.set(team, (eventTeamKills.get(team) || 0) + 1);
  }
  const noKills = s.killCoverageComplete && s.killEvents.length === 0 && s.players.size > 0 && [...s.scores.values()].every((value) => value === 0);
  const allGroups = [...new Set([...s.players.values()].map((p) => p.group))];
  const unmapped = sourceRoster(s) ? allGroups.filter((group) => !identity.has(group)) : [];
  const common = (values) => values.length && values.every((v) => v === values[0]) ? values[0] : null;
  const commonElims = !unknownKiller && !unmapped.some((group) => incomplete.has(group)) ? common(unmapped.map((group) => kills.get(group) || 0)) : null;
  const commonAlive = common(unmapped.map((group) => [...s.players.values()].filter((p) => p.group === group && p.alive).length));
  const rows = [...s.teams].map(([teamId, teamName]) => {
    const matches = registered.filter((t) => [t.name, t.abbreviation || ""].some((n) => n && teamNameKey(n) === teamNameKey(teamName)));
    if (matches.length > 1) errors.push("T\xEAn team tr\xF9ng danh s\xE1ch: " + teamName);
    const groups = [...identity].filter(([, id3]) => id3 === teamId).map(([group2]) => group2), group = groups.length === 1 ? groups[0] : void 0;
    const members = group === void 0 ? [] : [...s.players].filter(([, p]) => p.group === group).sort(([a], [b]) => a.localeCompare(b, void 0, { numeric: true }));
    const roster = members.map(([, p]) => p);
    const capacity = s.playersPerTeam ?? 4;
    const tracked = group === void 0 ? null : aggregateLife(s, group, members, capacity);
    const aliveStates = tracked ?? (group === void 0 ? null : Array.from({ length: capacity }, (_, i) => {
      const member = members[i];
      if (!member) return "unknown";
      return s.playerStates.get(member[0]) ?? (s.killCoverageComplete ? member[1].alive ? "alive" : "dead" : "unknown");
    }));
    const rosterComplete = roster.length > 0 && (s.playersPerTeam === null || roster.length <= s.playersPerTeam);
    const aliveCount = rosterComplete ? roster.filter((p) => p.alive).length : group === void 0 ? commonAlive : null;
    const elims = s.killCoverageComplete && !unknownKiller ? group !== void 0 && !incomplete.has(group) ? kills.get(group) || 0 : group === void 0 ? !unresolvedEventTeam ? eventTeamKills.get(teamId) || 0 : commonElims : null : noKills ? 0 : null;
    return { teamId: String(teamId), teamName, slot: null, elims, aliveCount, aliveStates, damage: null, placement: null };
  });
  const allAliveKnown = rows.every((r) => r.aliveCount !== null);
  const remainingPlayers = allAliveKnown ? rows.reduce((n, r) => n + (r.aliveCount || 0), 0) : null;
  const remainingTeams = allAliveKnown ? rows.filter((r) => (r.aliveCount || 0) > 0).length : null;
  const diagnostic = { teamCount: s.teams.size, scoreCount: s.scores.size, playerCount: s.players.size, groupMappingCount: identity.size, rosterIdentity: requireUidIdentity ? identityReady ? "uid-verified" : "pending" : "legacy-inferred", teamNames: rows.map((r) => r.teamName), rows, rawTeamScores: [...s.scores].map(([teamId, score]) => ({ teamId, score })), elimsMethod: "enemy-death-events", elimsCoverage: s.killCoverageComplete ? s.openingFlightSeen ? "observed-opening-flight" : "first-scoreboard-matches-observed-kills" : "missing-start", killEventCount: s.killEvents.length, detectedMatchId: s.matchId, sourceReplay: s.sourceReplay, source: "player-log", sourceEventAt: s.sampleAt, sourceEventAgeMs: s.sampleAt ? Math.max(0, now - s.sampleAt) : null, errors: errors.slice(0, 10) };
  if (errors.length) return { packet: null, diagnostic, message: errors.slice(0, 3).join(" ") };
  const packet = livePacketSchema.safeParse({ sessionId: sessionId2, configId: settings.configId, sequence: sequence2, matchId: settings.matchId, detectedMatchId: s.matchId, source: "game-log", isReplay: settings.mode === "replay", capturedAt: now, sourceEventAt: s.sampleAt || null, matchStartedAt: s.matchStartedAt, rosterProof: sourceRoster(s), captureSpanMs: 0, expectedTeams: settings.expectedTeams, complete: true, teams: rows, remainingTeams, remainingPlayers });
  return packet.success ? { packet: packet.data, diagnostic, message: "" } : { packet: null, diagnostic, message: packet.error.issues.map((x) => x.message).join(" ").slice(0, 500) };
}

// scripts/live-scoreboard-bridge.mjs
var arg = process.argv.indexOf("--config");
var path = resolve(arg >= 0 ? process.argv[arg + 1] : ".live-scoreboard.local.json");
var config = JSON.parse((await readFile(path, "utf8")).replace(/^\uFEFF/, ""));
var server = new URL(config.serverUrl);
if (!["http:", "https:"].includes(server.protocol) || server.username || server.password) throw Error("C\u1EA5u h\xECnh serverUrl kh\xF4ng h\u1EE3p l\u1EC7.");
if (typeof config.token !== "string" || config.token.length < 50) throw Error("Thi\u1EBFu kh\xF3a bridge. T\u1EA3i l\u1EA1i c\u1EA5u h\xECnh t\u1EEB web.");
var endpoint = new URL("/api/live-scoreboard/bridge", server);
var sessionId = randomUUID();
var folder = join(dirname(path), "live-bridge-work");
await mkdir(folder, { recursive: true });
var runtime = join(folder, "runtime.json");
var stopped = false;
var child = null;
var control = null;
var offset = 0;
var sequence = 0;
var processing = false;
var pending = null;
var lastPrint = "";
var lastCandidate = "";
var candidateCount = 0;
var lastNativeConfig = "";
var gameLog = createGameLogState();
var logOffset = 0;
var logPartial = "";
var logDecoder = new StringDecoder("utf8");
var lastLogGrowthAt = 0;
var lastLogSnapshotAt = 0;
var lastLogIdentity = "";
var rosterId = "";
var rosterPlayers = [];
var rosterRequest = null;
var rosterRetryAt = 0;
function refreshRoster() {
  const id3 = gameLog.matchId;
  if (!id3) return;
  if (rosterId !== id3) {
    rosterId = id3;
    rosterPlayers = [];
    rosterRetryAt = 0;
  }
  if (rosterPlayers.length) applyUidRoster(gameLog, id3, rosterPlayers);
  if (rosterRequest || Date.now() < rosterRetryAt || rosterPlayers.length) return;
  rosterRetryAt = Date.now() + 3e3;
  rosterRequest = fetchLivePlayerStats(id3).then((result) => {
    if (gameLog.matchId === id3) {
      rosterPlayers = result.players;
      applyUidRoster(gameLog, id3, rosterPlayers);
    }
  }).catch(() => {
  }).finally(() => {
    rosterRequest = null;
  });
}
function log(message) {
  if (message !== lastPrint) {
    console.log((/* @__PURE__ */ new Date()).toISOString() + " " + message);
    lastPrint = message;
  }
}
async function request(body) {
  const started = Date.now();
  const response = await fetch(endpoint, { method: body ? "POST" : "GET", headers: { Authorization: "Bearer " + config.token, ...body ? { "Content-Type": "application/json" } : {} }, body: body ? JSON.stringify(body) : void 0, signal: AbortSignal.timeout(4e3), cache: "no-store" });
  let data;
  try {
    data = await response.json();
  } catch {
    throw Error("M\xE1y ch\u1EE7 ch\u01B0a tr\u1EA3 ph\u1EA3n h\u1ED3i h\u1EE3p l\u1EC7.");
  }
  if (response.status === 401) {
    stopped = true;
    child?.kill();
    throw Error("Kh\xF3a bridge \u0111\xE3 \u0111\u1ED5i ho\u1EB7c kh\xF4ng h\u1EE3p l\u1EC7. T\u1EA3i c\u1EA5u h\xECnh m\u1EDBi.");
  }
  if (!response.ok) throw Error(data.error || "Kh\xF4ng g\u1EEDi \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u bridge.");
  if (!body && data.serverNow) offset = data.serverNow - (started + Date.now()) / 2;
  return data;
}
async function refreshControl() {
  const next = await request();
  next.settings = liveBoardSettingsSchema.parse(next.settings);
  control = next;
  const content = JSON.stringify({ configId: next.settings.configId, layout: next.settings.layout });
  if (content !== lastNativeConfig) {
    await writeFile(runtime, content);
    lastNativeConfig = content;
    lastCandidate = "";
    candidateCount = 0;
  }
  return next;
}
async function heartbeat(status, message, diagnostic = null) {
  log(message || status);
  await request({ action: "heartbeat", sessionId, status, message: String(message).slice(0, 500), diagnostic });
}
async function detectedMatch(frame) {
  try {
    const root = join(config.gameRoot || "D:/PC CLIENT/PC CLIENT 01", "Free Fire_64_Data");
    const names = (await readdir(root)).filter((name2) => /^MatchId_\d{1,24}_.*\.log$/i.test(name2));
    const files = await Promise.all(names.map(async (name2) => ({ name: name2, mtime: (await stat(join(root, name2))).mtimeMs })));
    const latest = files.filter((f) => f.mtime >= frame.processStartedAt - 5e3).sort((a, b) => b.mtime - a.mtime)[0];
    const id3 = latest?.name.match(/^MatchId_(\d{1,24})_/)?.[1];
    return id3 && id3 !== "0" ? id3 : null;
  } catch {
    return null;
  }
}
async function handleFrame(frame) {
  await refreshControl();
  const settings = control.settings;
  if (settings.adapter !== "windows-ocr") return;
  if (frame.type !== "frame") {
    await heartbeat("waiting", frame.message || "Ch\u1EDD c\u1EEDa s\u1ED5 game.");
    return;
  }
  if (frame.configId !== settings.configId) {
    await heartbeat("calibrating", "Ch\u1EDD khung theo c\u1EA5u h\xECnh m\u1EDBi.");
    return;
  }
  const result = packetFromOcr(frame, settings, control.teams, sessionId, ++sequence, await detectedMatch(frame), offset);
  const key = JSON.stringify(result.diagnostic.rows);
  candidateCount = key === lastCandidate ? candidateCount + 1 : 1;
  lastCandidate = key;
  if (!result.packet) {
    await heartbeat("partial", result.message, result.diagnostic);
    return;
  }
  if (candidateCount < 2) {
    await heartbeat("validating", "\u0110ang ki\u1EC3m tra \u0111\u1ED9 \u1ED5n \u0111\u1ECBnh qua hai khung.", result.diagnostic);
    return;
  }
  await request({ action: "snapshot", packet: result.packet });
  log("\u0110\xE3 g\u1EEDi " + result.packet.teams.length + " \u0111\u1ED9i \xB7 " + (result.packet.isReplay ? "REPLAY" : "LIVE") + " \xB7 Match " + result.packet.matchId);
}
async function consume() {
  if (processing) return;
  processing = true;
  try {
    while (pending && !stopped) {
      const frame = pending;
      pending = null;
      try {
        await handleFrame(frame);
      } catch (error) {
        log(error.message);
      }
    }
  } finally {
    processing = false;
  }
}
async function fileCycle() {
  await refreshControl();
  const s = control.settings;
  if (!s.sourcePath) {
    await heartbeat("waiting", "Ch\u1ECDn \u0111\u01B0\u1EDDng d\u1EABn file JSON chu\u1EA9n h\xF3a.");
    return;
  }
  let value;
  try {
    value = parseLosslessJson(await readFile(s.sourcePath, "utf8"));
  } catch {
    await heartbeat("source-error", "Ch\u01B0a \u0111\u1ECDc \u0111\u01B0\u1EE3c snapshot JSON chu\u1EA9n h\xF3a. Kh\xF4ng d\xF9ng tr\u1EF1c ti\u1EBFp ReplayInfo.");
    return;
  }
  const packet = livePacketSchema.parse({ ...value, source: "normalized-file", sessionId, configId: s.configId, sequence: ++sequence, capturedAt: Math.round(Number(value.capturedAt) + offset) });
  await request({ action: "snapshot", packet });
  log("\u0110\xE3 g\u1EEDi snapshot file \xB7 Match " + packet.matchId);
}
async function gameLogCycle() {
  const s = control.settings;
  const logPath = config.playerLogPath || join(process.env.USERPROFILE || "C:/Users/Public", "AppData", "LocalLow", "Garena", "Free Fire", "Player.log");
  let file, changed = false;
  try {
    file = await open(logPath, "r");
    const info = await file.stat();
    const identity = [info.dev, info.ino, info.birthtimeMs].join(":");
    if (lastLogIdentity && lastLogIdentity !== identity || info.size < logOffset) {
      logOffset = 0;
      logPartial = "";
      logDecoder = new StringDecoder("utf8");
      gameLog = createGameLogState();
    }
    lastLogIdentity = identity;
    const length = Math.min(4 * 1024 * 1024, Math.max(0, info.size - logOffset));
    if (length) {
      const buffer = Buffer.allocUnsafe(length);
      const { bytesRead } = await file.read(buffer, 0, length, logOffset);
      logOffset += bytesRead;
      lastLogGrowthAt = Math.min(Date.now(), info.mtimeMs);
      const text = logPartial + logDecoder.write(buffer.subarray(0, bytesRead));
      const lines = text.split(/\r?\n/);
      logPartial = lines.pop() || "";
      for (const line of lines) changed = consumeGameLogLine(gameLog, line) || changed;
    }
    if (logOffset < info.size) {
      await heartbeat("catching-up", "Reading earlier log events before publishing current scores.");
      return;
    }
  } catch (error) {
    await heartbeat("source-error", "Kh\xF4ng \u0111\u1ECDc \u0111\u01B0\u1EE3c Player.log c\u1EE7a client. " + String(error.message).slice(0, 250));
    return;
  } finally {
    await file?.close().catch(() => {
    });
  }
  if (!followsGame(s) && s.mode === "live" && gameLog.matchId && gameLog.matchId !== s.matchId) {
    await heartbeat("wrong-match", "Game \u0111\xE3 sang tr\u1EADn " + gameLog.matchId + ". \u0110\u1ED5i Match ID v\xE0 x\xE1c nh\u1EADn s\u1ED1 \u0111\u1ED9i tr\u01B0\u1EDBc khi chi\u1EBFu.", { source: "player-log", detectedMatchId: gameLog.matchId, teamCount: gameLog.teams.size, playerCount: gameLog.players.size });
    return;
  }
  if (followsGame(s) && !sourceSettings(gameLog, s)) {
    await heartbeat("detecting-match", "\u0110ang t\u1EF1 nh\u1EADn tr\u1EADn v\xE0 danh s\xE1ch \u0111\u1ED9i t\u1EEB game.", { source: "player-log", detectedMatchId: gameLog.matchId, sourceReplay: gameLog.sourceReplay, teamCount: gameLog.teams.size, playerCount: gameLog.players.size });
    return;
  }
  refreshRoster();
  const now = Date.now();
  if (gameLog.teams.size && gameLog.scores.size === gameLog.teams.size && (changed || now - lastLogSnapshotAt >= 2e3) && now - lastLogGrowthAt < 5e3) {
    const result = gameLogSnapshot(gameLog, s, control.teams, sessionId, ++sequence, now, s.mode === "live");
    if (result.packet) {
      await request({ action: "snapshot", packet: result.packet });
      await heartbeat("connected", "\u0110ang \u0111\u1ECDc Player.log \xB7 " + result.packet.teams.length + " team.", result.diagnostic);
      gameLog.dirty = false;
      lastLogSnapshotAt = now;
      if (changed) log("\u0110\xE3 \u0111\u1ECDc Player.log \xB7 " + result.packet.teams.length + " team \xB7 " + (result.packet.isReplay ? "REPLAY" : "LIVE") + " \xB7 Match " + result.packet.matchId);
    } else await heartbeat(result.diagnostic.rosterIdentity === "pending" ? "identity-pending" : "partial", result.message || gameLog.diagnostic, result.diagnostic);
  } else if (!gameLog.teams.size) await heartbeat("waiting", "Ch\u1EDD controller scoreboard ghi t\xEAn team v\xE0o Player.log.");
  else if (now - lastLogGrowthAt >= 5e3) await heartbeat("source-stale", "Player.log kh\xF4ng c\u1EADp nh\u1EADt trong 5 gi\xE2y; \u0111ang gi\u1EEF snapshot h\u1EE3p l\u1EC7 g\u1EA7n nh\u1EA5t.", { source: "player-log", teamCount: gameLog.teams.size, scoreCount: gameLog.scores.size, lastLogGrowthAt });
}
var cleanup = () => {
  stopped = true;
  child?.kill();
};
process.on("SIGINT", cleanup);
process.on("SIGTERM", cleanup);
await refreshControl();
await request({ action: "start", sessionId });
console.log("Bridge b\u1EA3ng \u0111i\u1EC3m \u0111\xE3 k\u1EBFt n\u1ED1i. Kh\xF4ng in kh\xF3a. Ctrl+C \u0111\u1EC3 d\u1EEBng.");
while (!stopped) {
  try {
    if (control.settings.adapter === "game-log") {
      if (child) {
        child.kill();
        child = null;
      }
      await refreshControl();
      await gameLogCycle();
    } else if (control.settings.adapter === "windows-ocr") {
      if (!child) {
        const native = join(dirname(fileURLToPath(import.meta.url)), "live-scoreboard-capture.ps1");
        child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", native, "-RuntimeConfig", runtime], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
        const processChild = child;
        const lines = createInterface({ input: child.stdout });
        lines.on("line", (line) => {
          try {
            pending = JSON.parse(line);
            void consume();
          } catch {
          }
        });
        child.stderr.on("data", () => log("B\u1ED9 \u0111\u1ECDc Windows g\u1EB7p l\u1ED7i. Ki\u1EC3m tra English OCR v\xE0 quy\u1EC1n ch\u1EE5p c\u1EEDa s\u1ED5."));
        child.on("exit", () => {
          if (child === processChild) child = null;
        });
      }
      if (!processing) await refreshControl();
    } else {
      if (child) {
        child.kill();
        child = null;
      }
      await fileCycle();
    }
  } catch (error) {
    log(error.message);
    if (!stopped) try {
      await heartbeat("source-error", error.message);
    } catch {
    }
  }
  await new Promise((resolve2) => setTimeout(resolve2, Math.max(500, Math.min(1500, config.intervalMs || 750))));
}
cleanup();
